		<div class="wrap">
		<div class="Header"><h2><?php _e("Ultimate FAQ Settings", 'EWD_UFAQ') ?></h2></div>

		<?php EWD_UFAQ_Add_Header_Bar("Yes"); ?>
		